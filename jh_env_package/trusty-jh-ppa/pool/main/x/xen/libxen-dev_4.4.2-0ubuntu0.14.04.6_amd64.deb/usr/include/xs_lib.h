#warning xs_lib.h is deprecated use xenstore_lib.h instead
#include <xenstore_lib.h>
